<?php
require_once('./classes/mgrid.router.php');

class ItemsRouter extends mGridRouter {

    // --- Database table description ---
    protected $SCHEMA = array(
        'table'     => "mgrid_items",
        'fields'    => "id,name,cost,note",
        'groups'    => array(
        						'table'		=> "mgrid_groups",
        						'bind'		=> "mgrid_item_group",
        						'fields'	=> "item_id,group_id"
        )
    );





    // =============================================
    // =============== ITEMS ACTIONS ===============
    // =============================================

    protected function fetch() {
        $params = $this->getFetchParameters();
        $data = $this->MAP->fetch( $params );
        $this->REQ->replyJson( $data, "Found ".count($data['items'])." rows");
    }

    protected function add( ) {
        $params = $this->getModifyParameters();
        $data = $this->MAP->add( $params );
        if ($data !== false) { $this->REQ->replyJson( $data, "Successfully added"); }
        else { $this->REQ->replyJsonError( "Add failed: " . $this->MAP->getError() ); }
    }

    protected function update( ) {
        $params = $this->getModifyParameters();
        $data = $this->MAP->update( $params );
        if ($data !== false) { $this->REQ->replyJson( $data, "Successfully updated"); }
        else { $this->REQ->replyJsonError( "Update failed: " . $this->MAP->getError() ); }
    }

    protected function remove( ) {
        $params = $this->getModifyParameters();
        $data = $this->MAP->remove( $params );
        if ($data) { $this->REQ->replyJson( $data , "Successfully removed"); }
        else { $this->REQ->replyJsonError( "Remove failed: ".$this->MAP->getError() ); }
    }

	protected function move() {
		$params = array(
						'id'  => (int)$this->REQ->getVar('item_id',0,false),
						'src' => $this->REQ->getVar('src_id',false,false),
				    	'dst' => $this->REQ->getVar('dst_id',false,false)
		);
		if ( ($params['src']=='all') || ($params['dst']=='all') ) { $this->REQ->replyJsonError( 'Can\'t move into/from All group' ); }

        $outGroups = $this->MAP->move( $params );
        if ( $outGroups !== false ) {
	        $this->REQ->replyJson(
	        	array( 'item_id' 	=> $params['id'],
	        		   'dst_id' 	=> $params['dst'],
	        		   'out_groups' => $outGroups
				), 'Item successfully moved');
        }
        else { $this->REQ->replyJsonError( "Moving failed: ".$this->MAP->getError() ); }
    }

	protected function copy() {
		$params = array(
						'id'  => (int)$this->REQ->getVar('item_id',0,false),
						'src' => $this->REQ->getVar('src_id',false,false),
				    	'dst' => $this->REQ->getVar('dst_id',false,false)
		);
		if ( $params['dst']=='all' ) { $this->REQ->replyJsonError( 'Not define destination group' ); }

        $outGroups = $this->MAP->copy( $params );
        if ( $outGroups !== false ) {
	        $this->REQ->replyJson(
	        	array( 'item_id' 	=> $params['id'],
	        		   'dst_id' 	=> $params['dst'],
	        		   'out_groups' => $outGroups
				), 'Item successfully copied');
        }
        else { $this->REQ->replyJsonError( "Coping failed: ".$this->MAP->getError() ); }
    }



    // =============================================
    // =============== GROUPS ACTIONS ==============
    // =============================================

    protected function group_fetch() {
        $data = $this->MAP->fetchGroups();
        $this->REQ->replyJson( $data , "Found ".count($data['groups'])." groups" );
    }

    protected function group_add() {
        $params = $this->getModifyParameters();
        $data = $this->MAP->addGroup( $params );
        if( $data ) { $this->REQ->replyJson( $data, 'Group succesfully added' ); }
        else { $this->REQ->replyJsonError('Group adding failed: '.$this->MAP->getError() ); }
    }

    protected function group_update() {
        $params = $this->getModifyParameters();
        $data = $this->MAP->updateGroup( $params );
        if($data !== false) { $this->REQ->replyJson( $data, 'Group succesfully updated' ); }
        else { $this->REQ->replyJsonError('Group updating failed: '.$this->MAP->getError() ); }
    }

    protected function group_remove() {
        $params = $this->getModifyParameters();
        $data = $this->MAP->removeGroup( $params );
        if ($data !== false) { $this->REQ->replyJson( $data, 'Group succesfully removed' ); }
        else { $this->REQ->replyJsonError('Group removing failed: '.$this->MAP->getError() ); }
    }

    protected function group_clear( ) {
        $params = $this->getModifyParameters();
        $data = $this->MAP->clearGroup( $params );
        if ($data !== false) { $this->REQ->replyJson( $data, 'Group succesfully cleared' ); }
        else { $this->_REQ->replyJsonError('ClearGroup failed: '.$this->_MAP->getError() ); }
    }













    /*



    private function copy( ) {
		$data = array(
						'src' => $this->_REQ->getVar('src_id',false,false),
				    	'dst' => $this->_REQ->getVar('dst_id',false,false),
				    	'id'  => (int)$this->_REQ->getVar('item_id',0,false)
		);
		if (!$data['id'] || $data['src']===false || $data['dst']===false) { $this->_REQ->replyJsonError( 'Not enought parameters' ); }
        if ( $data['dst']=='all' ) { $this->_REQ->replyJsonError( 'Not define destination group' ); }

        $outGroups = $this->_MAP->copyItem( $data );
        if ( $outGroups !== false ) {
	        $this->_REQ->replyJson( array( 'item_id' => $data['id'], 'dst_id' => $data['dst'], 'out_groups' => $outGroups ), 'Item successfully copied');
        }
        $this->_REQ->replyJsonError( "Copy failed: ".$this->_MAP->getError() );
    }


    private function move( ) {
		$data = array(
						'src' => $this->_REQ->getVar('src_id',false,false),
				    	'dst' => $this->_REQ->getVar('dst_id',false,false),
				    	'id'  => (int)$this->_REQ->getVar('item_id',0,false)
		);
		if (!$data['id'] || $data['src']===false || $data['dst']===false) { $this->_REQ->replyJsonError( 'Not enought parameters' ); }
		if ( $data['src']=='all' ||  $data['dst']=='all' ) { $this->_REQ->replyJsonError( 'Not define source/destination group' ); }

        $outGroups = $this->_MAP->moveItem( $data );
        if ( $outGroups !== false ) {
	        $this->_REQ->replyJson( array( 'item_id' => $data['id'], 'dst_id' => $data['dst'], 'out_groups' => $outGroups ), 'Item successfully moved');
        }
        $this->_REQ->replyJsonError( "Move failed: ".$this->_MAP->getError() );

    }

    */




}

CREATE TABLE IF NOT EXISTS `mgrid_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1;
INSERT INTO `mgrid_groups` (`id`, `name`) VALUES (1, 'Asia'), (2, 'Europa');


CREATE TABLE IF NOT EXISTS `mgrid_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `cost` int(5) unsigned DEFAULT NULL,
  `note` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1;
INSERT INTO `mgrid_items` (`id`, `name`, `cost`, `note`) VALUES (1, 'Honda', 14, 'japan'), (2, 'Lexus', 136, 'japan'), (3, 'BMW', 320, 'german'), (4, 'Fiat', 45, 'spain'), (5, 'Hynday', 100, 'korea');


CREATE TABLE IF NOT EXISTS `mgrid_item_group` (
  `item_id` int(10) DEFAULT NULL,
  `group_id` int(10) DEFAULT NULL
) ENGINE=InnoDB;
INSERT INTO `mgrid_item_group` (`item_id`, `group_id`) VALUES (1, 1), (2, 1), (3, 2), (4, 2);

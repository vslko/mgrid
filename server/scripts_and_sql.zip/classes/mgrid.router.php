<?php
require_once("./classes/class.request.php");
require_once("./classes/class.database.php");
require_once("./classes/mgrid.mapper.php");

class mGridRouter  {

    protected $REQ;

    protected $MAP;

    protected $SCHEMA = array(
    						'table' 	=> "table",
    						'fields' 	=> "id",
    						'groups'	=> false
    );



    public function __construct( $db_settings ) {
    	$this->_dbsettings_ = $db_settings;
    }




    /* entry point */
    public function route() {

		$this->REQ = new Request();

		$link = new Database();
		if ( $link->connect($this->_dbsettings_) === false ) {
		    $this->REQ->replyJsonError( $link->getError() );
		}

        $this->MAP = new MGridMapper( $link, $this->SCHEMA );

		/* Routing by variable 'action' */
		$action = strtolower($this->REQ->getVar('action'));
		if ( !method_exists($this, $action) ) {
			$this->REQ->replyJsonError('Bad request: unknown action');
		}

        call_user_func( array($this, $action) );

    }




    protected function getFetchParameters() {		// collect mandatory parameter to view data in grid
		$params = array(
            			 '_page'  => (int) $this->REQ->getVar('_page', 1),     // page number
		            	 '_recs'  => (int) $this->REQ->getVar('_recs', 0),     // records on page
		            	 '_scol'  =>       $this->REQ->getVar('_scol', null),  // sorting column
		            	 '_sord'  =>       $this->REQ->getVar('_sord', "asc"), // sorting order
        );

        // collect groupId if there is groupped grid
        if ( $this->SCHEMA['groups'] !== false ) { $params['_group'] = $this->REQ->getVar('_group', 0); }
        return $params;
    }



    protected function getModifyParameters() {        $params = array();

    	// collect data-feilds
    	$fields = $this->MAP->getFieldsBySchema();
        foreach($fields as $i => $f) {        	if ( $this->REQ->getVar($f, null) ) {        		$params[$f] = $this->REQ->getVar($f, '');        	}
        }

        // collect groupId if there is groupped grid
        if ( $this->SCHEMA['groups'] !== false ) { $params['_group'] = $this->REQ->getVar('_group', 0); }

    	return $params;    }



}
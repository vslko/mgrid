<?php

class Request {

    public function __construct() { /* do nothing*/ }

    public function getVar($varname, $defaultValue=null) {
        return ( isset($_REQUEST[$varname]) ? $_REQUEST[$varname] : $defaultValue );
    }

    public function isAjax() {
        return ( isset($_SERVER['HTTP_X_REQUESTED_WITH'])
                   && !empty($_SERVER['HTTP_X_REQUESTED_WITH'])
                     && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' );
    }

    public function replyJsonError($errorMessage) {
        $reply = array( 'success'=>false, 'message'=>$errorMessage );
        $this->sendJson( $reply );
    }

    public function replyJson( $data , $message="") {
        $reply =array( 'success'=>true, 'message'=>$message, 'data'=>$data );
        $this->sendJson( $reply );
    }

    private function sendJson( $reply ) {
        header('Cache-Control: no-cache, must-revalidate');
        header('Expires: Sun, 01 Jan 2001 01:01:01 GMT');
        header('Content-type: application/json');
        print( json_encode($reply) );
        exit;
    }

}
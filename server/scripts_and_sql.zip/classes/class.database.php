<?php

class Database {

    const SUCCESS         = null;

    private $dbLink     = null;
    private $dbError     = null;


    /* escape symbols for this database and return escaped string */
    public function safe($value) {
        return ($this->dbLink) ? mysqli_real_escape_string($this->dbLink, $value) : addslashes($value);
    }


    /* Return:
         true - on siccessfully connection
         false - on connection error
    */
    public function connect( $params ) {
        $db = null;
        $host = ( (int)$params['port']>0 ) ? $params['host'].":".$params['port'] : $params['host'];
        if ( !($db = @mysqli_connect($host,$params['username'],$params['password'],$params['database'])) ) {
            return $this->_setError( mysqli_connect_error() );
        }
          if ( !@mysqli_query($db, "SET NAMES '".$params['charset']."'" ) ) {
              return $this->_setError( mysqli_error($db) );
          }
        $this->dbLink = $db;
        return $this->_setError( self::SUCCESS );
    }


    /* Return always TRUE */
    public function disconnect() {
        mysqli_close($this->dbLink);
        return $this->_setError( self::SUCCESS );
    }


    /* Return:
         false - on error
         assoc array - on SELECT and SHOW queries
         id - on INSERT query
         affected rows - on DELETE, REPLACE and UPDATE queries
    */
    public function execSQL( $query ) {
        $result = null;

        if (!($res = @mysqli_query($this->dbLink , $query))) {  return $this->_setError( mysqli_error($this->dbLink) ); }

        $what_return = strtoupper( substr($query,0,strpos(trim($query),' ')) );
        switch( $what_return ) {
            case 'SELECT' :
            case 'SHOW'   : while ($row = mysqli_fetch_assoc($res)) { $result[] = $row; }
                            break;

            case 'INSERT' : $result = mysqli_insert_id($this->dbLink);
                            break;

            case 'UPDATE' :
            case 'REPLACE':
            case 'DELETE' : $result = mysqli_affected_rows($this->dbLink);
                            break;
        }
        @mysqli_free_result($res);

        return $result;
    }


    /* Return last error and clear it */
    public function getError() {
        $msg = $this->dbError;
        $this->dbError = null;
        return $msg;
    }


    private function _setError( $msg=null ) {
        $this->dbError = $msg;
        return !$msg;
    }

}

<?php

class mGridMapper {

    private $_DB;
    private $_SCHEMA;

    public function __construct( $connection, $schema ) {
        $this->_DB         = $connection;
        $this->_SCHEMA    = $schema;
    }


    public function getError() {
        return $this->_DB->getError();
    }




    // -------------------------------------------------
    // ------------------ ITEMS ACTIONS -----------------
    // -------------------------------------------------

    public function fetch( $p ) {
        $fields = $this->getFieldsBySchema();

        $G = false;  // grid with (G)roups or not
        if ( ($this->_SCHEMA['groups'] !== false) && !empty($p['_group']) ) {
            $G = true;
            $bind_fields = $this->getBindFieldsBySchema();
        }

        $sql = null;
        foreach($fields as $i => $f) {
            $sql .= ( ($sql) ? "," : "" ) . $this->_SCHEMA['table'].".".$f ;
        }
        $sql = "SELECT " . $sql .
               ( $G ? ", (select GROUP_CONCAT(".$bind_fields[1].") from ".$this->_SCHEMA['groups']['bind']." where ".$bind_fields[0]." = ".$this->_SCHEMA['table'].".".$fields[0].") as _groups" : "" ) .
               " FROM " . $this->_SCHEMA['table'] ;

        if ( $G ) {
            switch ( $p['_group'] ) {
                case 'all': $WHERE = ""; break;
                case 'not': $WHERE = "WHERE ".$fields[0]." NOT IN (select ".$bind_fields[0]." from ".$this->_SCHEMA['groups']['bind'].")"; break;
                default: $WHERE = ", ".$this->_SCHEMA['groups']['bind']."
                                  WHERE ".$this->_SCHEMA['groups']['bind'].".".$bind_fields[1]."='".$this->_DB->safe($p['_group'])."'
                                          AND ".$this->_SCHEMA['groups']['bind'].".".$bind_fields[0]."=".$this->_SCHEMA['table'].".".$fields[0];
            }
        }

        $limit = $p['_recs'] ? ( "LIMIT " . ( ($p['_page']-1) * $p['_recs'] ) . "," . $p['_recs'] ) : NULL;
        $order = $p['_scol'] ? ( "ORDER BY `" . $p['_scol'] . "` " . $p['_sord'] ) : NULL;
        $sql =  $sql . " " . $WHERE . " " . $ORDER . " " . $LIMIT;

        $data = $this->_DB->execSQL( $sql );
        if ( $G ) {
            for($i=0; $i<count($data); $i++) {
                $data[$i]['_groups'] = empty($data[$i]['_groups']) ? array() : explode( ",", $data[$i]['_groups'] );
            }
        }
        return (
                 array(
                        'page'  => $p['page'],
                        'total' => $this->_getTotal(),
                        'items' => $data ? $data : array()
                 )
        );
    }


    public function add( $p ) {
        $G = ( ($this->_SCHEMA['groups'] !== false) && ( intval($p['_group']) > 0 ) );

        $keys = null;
        $values = null;
        $fields = $this->getFieldsBySchema();

        foreach($fields as $i => $f) {
            $keys .= ( ($keys) ? "," : "" ) . "`".$f."`";
            $values .=  ( ($values) ? "," : "" ) . ( empty($p[$f]) ? "NULL" : "'".$this->_DB->safe($p[$f])."'" );
        }

        $sql = "INSERT INTO `" . $this->_SCHEMA['table'] . "`" .
               "(" . $keys . ") ".
               "VALUES( " . $values . ")";
        $id = $this->_DB->execSQL( $sql );

        if ($id && $G) { $this->_bind( $id , $p['_group'] ); }

        return ( $id ? $this->_get($id) : false );
    }


    public function update( $p ) {
        $fields = $this->getFieldsBySchema();

        $sql = null;
        for($i=1; $i<count($fields); $i++) {
            $f = $fields[$i];
            $sql .= ( ($sql) ? ", " : "" ) . "`".$f."`='" . $this->_DB->safe($p[$f]) . "' ";
        }
        $id = $p[$fields[0]];

        $sql = "UPDATE `" . $this->_SCHEMA['table'] . "` " .
               "SET " . $sql .
               "WHERE `" . $fields[0] . "`='" . $this->_DB->safe($id) . "'";
        return ( $this->_DB->execSQL($sql) ? $this->_get( $id ) : false );
    }


    public function remove( $p ) {
        $G = ($this->_SCHEMA['groups'] !== false);

        $fields = $this->getFieldsBySchema();
        $id = $p[$fields[0]];
        if (!$id) { return false; }

        if ($id && $G) { $this->_unbind( $id, null ); }

        $sql = "DELETE FROM `" . $this->_SCHEMA['table'] . "`" .
               "WHERE `" . $fields[0] . "`='" . $this->_DB->safe($id) . "'";
        return ( (boolean)$this->_DB->execSQL($sql) ? $id : false );
    }


    public function move( $p ) {		if ($p['dst'] == 'not') { // from [any] group to [not] group
        	$itemData = $this->_get( $p['id'] );
        	$this->_unbind( $p['id'], null);
        	return $itemData['_groups'];
		}
		else if ( $data['src'] == 'not' ) {  // from [not] group to [any] group
            $this->_bind( $p['id'], $p['dst'] );
            return array('not');
 		}
        else {  // from [any] group to other [any] group
        	$this->_unbind( $p['id'] , $p['src'] );
        	$this->_bind( $p['id'] , $p['dst'] );
        	return array( $p['src'] );
        }
    }

    public function copy( $p ) {
        $itemData = $this->_get( $p['id'] );

		if ($p['dst'] == 'not') {  // copy from [any|all] group to [not] group == move to [not] group
        	$this->_unbind( $p['id'], null);
        	return $itemData['_groups'];
		}
		else if ( empty( $itemData['_groups'] ) ) { // copy from [not] group to [any] group == move from [not] group
            $this->_bind( $p['id'], $p['dst']);
            return array('not');
 		}
        else { // copy from [any] to [any] group
        	$this->_bind( $p['id'], $p['dst'] );
        	return array();
        }
    }



    // -------------------------------------------------
    // ----------------- GROUPS ACTIONS ----------------
    // -------------------------------------------------

    public function fetchGroups( $p = null ) {
        return (
                 array( 'total'   => $this->_getTotal(),
                        'without' => $this->_getTotalWithoutGroup(),
                        'groups'  => $this->_getGroups() )
        );
    }


    public function addGroup( $p ) {
        $sql = "INSERT INTO `" . $this->_SCHEMA['groups']['table'] . "`(id, name) " .
               "VALUES ( null , '" . $this->_DB->safe($p['name']) . "' )";
        $id = $this->_DB->execSQL( $sql );
        return ( ( $id ) ? $this->_getGroups($id)    : false );
    }


    public function updateGroup( $p ) {
        $id = $p['id'];
        $sql = "UPDATE `" . $this->_SCHEMA['groups']['table'] . "`
                SET name='".$this->_DB->safe($p['name'])."'
                WHERE id=".$id;
        return ( $this->_DB->execSQL($sql) ?  $this->_getGroups( $id ) : false );
    }


    public function removeGroup( $p ) {
        $id = $p['id'];

        $sql = "DELETE FROM `" . $this->_SCHEMA['groups']['table'] . "` WHERE id=" . $id;
        if ( $this->_DB->execSQL( $sql ) ) {
            $this->_unbind( null, $id );
            return array(
                          'id'        => $id,
                          'without' => $this->_getTotalWithoutGroup()
            );
        }
        return false;
    }


    public function clearGroup( $p ) {
        $id = $p['id'];
        $this->_unbind( null, $id );
        return array(
                      'id'        => $id,
                      'without' => $this->_getTotalWithoutGroup()
        );
    }







    // -------------------------------------------------
    // -------------------- HELPERS --------------------
    // -------------------------------------------------

    // get count of items
    private function _getTotal() {
        $sql = "SELECT count(*) as cnt FROM `" . $this->_SCHEMA['table']."`";
        $data = $this->_DB->execSQL( $sql );
        return ( $data ? (int)$data[0]['cnt'] : 0 );
    }

    // get count of items without group
    private function _getTotalWithoutGroup() {
        $bind_fields = $this->getBindFieldsBySchema();
        $sql = "SELECT count(*) as cnt FROM `" . $this->_SCHEMA['table'] . "` " .
               "WHERE id NOT IN (select `".$bind_fields[0]."` from `" . $this->_SCHEMA['groups']['bind'] . "`)";
        $data = $this->_DB->execSQL( $sql );
        return ( $data ? (int)$data[0]['cnt'] : 0 );
    }

    // get list of group or one group if isset groupId from database
    private function _getGroups( $groupId = null ) {
        $bind_fields = $this->getBindFieldsBySchema();
        $sql = "SELECT id, name,
                       ( select count(*) from `" . $this->_SCHEMA['groups']['bind'] . "` where `".$bind_fields[1]."`=id ) as items
                FROM `" . $this->_SCHEMA['groups']['table'] . "`" .
                ( $groupId ? " where id=".$groupId : "" );
        $data = $this->_DB->execSQL( $sql );
        return ( $groupId ? $data[0] : $data );
    }

    // get one item by id
    private function _get( $id ) {
        $fields = $this->getFieldsBySchema();

        $G = false;  // grid with (G)roups or not
        if ( ($this->_SCHEMA['groups'] !== false) ) {
            $G = true;
            $bind_fields = $this->getBindFieldsBySchema();
        }

        $sql = null;
        foreach($fields as $i => $f) { $sql .= ( ($sql) ? "," : "" ) . "`".$f."`" ; }
        if( $G ) {
            $sql .=  ", (select GROUP_CONCAT(".$bind_fields[1].") from ".$this->_SCHEMA['groups']['bind']." where ".$bind_fields[0]." = ".$this->_SCHEMA['table'].".".$fields[0].") as _groups";
        }
        $sql = "SELECT " . $sql . "
                FROM `" . $this->_SCHEMA['table'] . "`
                WHERE `".$fields[0]."`='".$this->_DB->safe($id)."'";

        $data = $this->_DB->execSQL($sql);
        if( $G && isset($data[0])) {
            $data[0]['_groups'] = empty($data[0]['_groups']) ? array() : explode( ",", $data[0]['_groups'] );
        }
        return ( isset($data[0]) ? $data[0] : false );
    }

    // bind item and group
    private function _bind( $item_id, $group_id) {
        $sql = "INSERT INTO " . $this->_SCHEMA['groups']['bind'] . "
                VALUES( '".$item_id."', '".$group_id."' )";
        $this->_DB->execSQL($sql);
    }

    // unbind items fro group / groups from items
    private function _unbind( $item_id=null, $group_id=null) {
        $bind_fields = $this->getBindFieldsBySchema();
        $sql = "DELETE FROM `" . $this->_SCHEMA['groups']['bind'] . "` " .
               "WHERE " . ( $item_id ? "`".$bind_fields[0]."`='".$item_id."'" : "" ) .
                          ( $group_id ? ($item_id ? " and" : "") . "`".$bind_fields[1]."`='".$group_id."'" : "" );
        $this->_DB->execSQL( $sql );
    }

    // get array of item's fields
    public function getFieldsBySchema( $withKey = true ) {
        $fields = explode( ",", str_replace(" ","", $this->_SCHEMA['fields']) );
        if( !$withKey ) { array_shift ($fields); }
        return $fields;
    }

    // get array of fields in bind table
    public function getBindFieldsBySchema() {
        return ( explode( ",", str_replace(" ","", $this->_SCHEMA['groups']['fields']) ) );
    }


}
<?php
$settings = array(
	'host'     => "localhost",
	'port'     => 3306,
	'username' => "root",
	'password' => "password",
	'database' => "db_name",
	'charset'  => "utf8"
);

require_once('./items.router.php');
$router = new ItemsRouter( $settings );
$router->route();
